/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_28_luiz_felipe;

/**
 *
 * @author lbizio
 */
public class PROJETO_28_LUIZ_FELIPE {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
