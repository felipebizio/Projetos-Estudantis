/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.porjeto_19_bingo_luiz_felipe;


import java.util.Random;
import java.util.Scanner;

public class Projeto_19_Capixaba_Cap_Luiz_Felipe {

    public static void main(String[]args){
        //Tamanho da matriz
        int linhas = 20;
        int colunas = 20;
        
        //Criar a matriz
        int[][] matriz = new int[linhas][colunas];
        
        //Criar um objeto Randon para gerar números aleatórios
        Random random = new Random();
        
        //Preencher a matriz com números aletórios
        for (int i=0; i<linhas;i++){
            for(int j=0; j<colunas; j++){
                matriz[i][j]= random.nextInt(401); //Gera números aleatórios de 0 a 400    
            }
        }
        Scanner ler = new Scanner(System.in);
        int pont = 0;
        for(int k=0; k<10;k++){
            System.out.println("Digite um número para ser verificado:");
              int num = ler.nextInt();
                for (int i=0; i<linhas; i++){
                    for(int j=0; j<colunas;j++){
                    if (num == matriz[i][j]){
                            pont = pont + 1;
                        }
                    } 
                }
                System.out.println("Parabéns!! Você acertou: "+pont+ " números!");
        }
    } 
}
