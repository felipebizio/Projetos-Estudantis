/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_24_spock_input_luiz_felipe;

import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author felip
 */
public class Projeto_24_Spock_Input_Luiz_Felipe {

    public static void main(String[] args) {
       Scanner ler = new Scanner(System.in);
       Random random = new Random();
       boolean cont = true;
       int comp = 0; 
       int jog1 = 0;
       int resultado = 0;
               
       String[] v = {"Pedra", "Papel", "Tesoura", "lagarto", "Spock"};
       
        JOptionPane.showMessageDialog(null,"BEM VINDO AO JOKENPO");
        JOptionPane.showMessageDialog(null,"------REGRAS NO CONSOLE------");
        System.out.println("pedra vence a tesoura e lagarto");
        System.out.println("Tesoura vence o papel e lagarto");
        System.out.println("tesoura perde para a pedra e spock");
        System.out.println("Papel vence a pedra e spock");
        System.out.println("Papel perde para a tesoura e lagarto");
        System.out.println("spock vence a tesoura e pedra");
        System.out.println("spock perde para papel e lagarto");
        System.out.println("lagarto vence o papel e spock");
        System.out.println("lagarto perde para pedra e tesoura");
        System.out.println("------------------------------------------");
        
        while(cont){
       
        String esc = JOptionPane.showInputDialog(null,"Digite [ 1 ]Pedra, [ 2 ]Papel, [ 3 ]Tesoura, [ 4 ]Lagarto [ 5 ]Spock");
        jog1 = Integer.parseInt(esc);
        comp = random.nextInt(5)+1;
        
        if(jog1 <1 || jog1 >5){
            System.out.println("Opção invalida! Digite uma opção valida.");
            cont = true;
            }else{
            cont = false;
            }
        }
        System.out.println("Jogador 1 escolheu: " + v[jog1 - 1]);
        System.out.println("Computador escolheu: " + v[comp - 1]);
        
        switch(jog1){
            case 1:
               resultado = escPedra(comp);
                break;
            case 2:
               resultado = escPapel(comp);
                break;
            case 3:
               resultado = escTesoura(comp);
                break;
            case 4:
               resultado = escLagarto(comp);
                break;
            case 5:
               resultado = escSpock(comp);
                break;
        }switch (resultado) {
            case 0:
                System.out.println("EMPATE!");
                break;
            case 1:
                System.out.println("Jogador 1 venceu!");
                break;
            case 2:
                System.out.println("Computador venceu");
                break;
            default:
                break;
        }
    }
   
    private static int escPedra(int comp) {
        
        if(comp == 1){
            return 0;
        }else if(comp == 2 || (comp == 5)){
                return 2;
                }else{
                     return 1;
        }
    }
    
    private static int escPapel(int comp) {
        
        if(comp == 2){
            return 0;
        }else if(comp == 1 || (comp == 5)){
                return 2;
                }else{
                     return 1;
        }
    }
    
    private static int escTesoura(int comp) {
        if(comp == 3){
            return 0;
        }else if(comp == 1 || (comp == 4)){
                return 2;
                }else{
                     return 1;
        } 
    }
   
    private static int escLagarto(int comp) {
        if(comp == 4){
            return 0;
        }else if(comp == 1 || (comp == 3)){
                return 2;
                }else{
                     return 1;
        } 
    }
   
    private static int escSpock(int comp) {
        if(comp == 5){
            return 0;
        }else if(comp == 2 || (comp == 4)){
                return 2;
                }else{
                     return 1;
        }
    }
    }

