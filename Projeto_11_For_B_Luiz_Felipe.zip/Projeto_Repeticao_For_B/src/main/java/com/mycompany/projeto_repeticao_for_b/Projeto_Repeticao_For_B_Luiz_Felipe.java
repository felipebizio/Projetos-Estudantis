/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_repeticao_for_b;

/**
 *
 * @author lbizio
 */
public class Projeto_Repeticao_For_B_Luiz_Felipe {

    public static void main(String[] args) {
        
        for(int i=10;i>=1; i--){
            System.out.println(i);
        }
    }
}
