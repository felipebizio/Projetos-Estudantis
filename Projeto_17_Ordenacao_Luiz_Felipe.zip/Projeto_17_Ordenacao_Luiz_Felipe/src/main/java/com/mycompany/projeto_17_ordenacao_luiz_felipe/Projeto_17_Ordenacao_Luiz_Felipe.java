/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_17_ordenacao_luiz_felipe;

import java.util.Scanner;

public class Projeto_17_Ordenacao_Luiz_Felipe {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        int n = 10;
        int v[] = new int[n];
        int i;
        int j;
        
        for (i=0; i<n; i++){
            System.out.println("Informe um valor:");
            v[i] = ler.nextInt();
        }
        int copia;
        for (j=0; j<n;j++){
            copia = v[j];
            int indice = j;
            while(indice>0 && v[indice-1]>copia){
                v[indice] = v[indice-1];
                indice--;
            }
            v[indice] = copia;
        }
        for (i = 0; i <10; i++){
            System.out.printf(v[i]+ "|");
        }
    }
}
