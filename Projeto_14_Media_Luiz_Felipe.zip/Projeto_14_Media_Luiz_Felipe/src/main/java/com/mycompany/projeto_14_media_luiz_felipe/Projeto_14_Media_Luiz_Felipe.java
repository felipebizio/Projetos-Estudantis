/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_14_media_luiz_felipe;

import java.util.Scanner;   

public class Projeto_14_Media_Luiz_Felipe {

    public static void main(String[] args) {
        Scanner ler = new Scanner (System.in);

        System.out.println("Digite a primeira nota:");
         float n1 = ler.nextInt();
        System.out.println("Digite a segunda nota:");
         float n2 = ler.nextInt();
        
        
        if (n1 >= 0 &&  n1 <= 10 && n2 >=0 && n2<=10) {
          System.out.println("A média é: " + (n1+n2)/2);    
        }else{
            System.out.println("Voce digitou uma valor incorreto");
        }
        
       
         
             
      
    }
}
