/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_20_numero_primos;

import java.util.Scanner;
public class Projeto_20_Numero_Primos_Luiz_Felipe {

    public static void main(String[] args) {
        Scanner ler  = new Scanner(System.in);
        System.out.println("Digite um número:");
        int num = ler.nextInt();
        primo(num);
       
    }
    
    public static void primo (int num){
        int result=0;
        for(int i=1; i<= num; i++){
            if(num %i ==0){
                result=(result +1);
                if(result>2){
                    System.out.println("O número " + num + " não é primo!");
                    break;
                }
            }
        }
        if(result == 2){
            System.out.println("O número " + num + " é primo!");
        }   
    } 
}
    