/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_16_luiz_felipe;

/**
 *
 * @author lbizio
 */
public class Projeto_16_Luiz_Felipe {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
