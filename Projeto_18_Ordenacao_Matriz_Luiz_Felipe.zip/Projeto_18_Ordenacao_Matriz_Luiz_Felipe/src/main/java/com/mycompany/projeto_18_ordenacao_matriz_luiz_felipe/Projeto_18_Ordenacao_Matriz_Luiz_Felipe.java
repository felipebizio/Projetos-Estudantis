/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_18_ordenacao_matriz_luiz_felipe;

/**
 *
 * @author felip
 */
public class Projeto_18_Ordenacao_Matriz_Luiz_Felipe {

    public static void main(String[] args) {
        int [][] matriz = {{9,3,6},{5,1,4},{8,2,7}};
            
            for (int i=0; i<3;i++){
                for(int j=0; j<3; j++){
                    for(int k=0;k<3;k++){
                        for(int l=0; l<3;l++){
                            if(matriz[i][j]< matriz[k][l]){
                                int copia = matriz[i][j];
                                matriz[i][j] = matriz[k][l];
                                matriz[k][l] = copia;
                            }
                        }
                    }
                }
            }
            for (int i=0; i<3;i++){
                for(int j=0; j<3;j++){
                    System.out.println(matriz[i][j]+ " ");
                }
            }
    }
}
