/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_23_primeiro_data_input_stream;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author felip
 */
public class Projeto_23_Primeiro_Data_Input_Stream {

    public static void main(String[] args) throws IOException {
        String s="";
        float media=0, soma=0;
        float v[] = new float[4];
        DataInputStream  dado;
        
        for(int i=0;i<4;i++){
        System.out.println("digite a "+ (i+1)+"° nota");
        dado = new DataInputStream(System.in);
        s = dado.readLine();
        v[i]= Float.parseFloat(s);
        }
        for(int i=0;i<4;i++){
            soma= soma +v[i];
        }
        media = soma/4;
        System.out.println(media);            
   }
}
