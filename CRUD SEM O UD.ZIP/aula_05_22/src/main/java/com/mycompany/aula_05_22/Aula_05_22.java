/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula_05_22;

/**
 *
 * @author lbizio
 */
public class Aula_05_22 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
