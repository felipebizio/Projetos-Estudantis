/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.primeiro_projeto;

/**
 *
 * @author lbizio
 */
public class ATIVIDADE_03_Luiz_Felipe {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
