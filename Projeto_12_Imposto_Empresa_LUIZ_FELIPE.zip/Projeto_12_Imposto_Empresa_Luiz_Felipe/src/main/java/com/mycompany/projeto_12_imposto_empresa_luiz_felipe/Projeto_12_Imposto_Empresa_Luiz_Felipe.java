/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_12_imposto_empresa_luiz_felipe;

import java.util.Scanner;

/**
 *
 * @author lbizio
 */
public class Projeto_12_Imposto_Empresa_Luiz_Felipe {

    public static void main(String[] args) {
        Scanner ler = new Scanner (System.in);
        
        
        System.out.println("Digite um valor:");
        double valor = ler.nextDouble();
        
        System.out.println("Digite um estado:");
        String estado = ler.next();
         
        if(estado.equalsIgnoreCase("MG")){
            System.out.println(valor+(valor*0.07));
        }
        else if(estado.equalsIgnoreCase("SP")){
            System.out.println(valor+(valor*0.12)); 
        }
        else if(estado.equalsIgnoreCase("RJ")){
            System.out.println(valor+(valor*0.15)); 
        }
        else if(estado.equalsIgnoreCase("MS")){
            System.out.println(valor+(valor*0.08));
        } 
        else {
            System.out.println("ERRO! Digite um caracter válido!");
        }
    }
}
