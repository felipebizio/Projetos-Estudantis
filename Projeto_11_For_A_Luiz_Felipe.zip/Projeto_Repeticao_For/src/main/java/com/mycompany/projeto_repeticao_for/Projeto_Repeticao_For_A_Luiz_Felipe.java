/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_repeticao_for;
   
/**
 *
 * @author lbizio
 */
public class Projeto_Repeticao_For_A_Luiz_Felipe {

    public static void main(String[] args) {
        
        for(int i=1; i<=10;i++){
            System.out.println(i);
        }
    }
}
