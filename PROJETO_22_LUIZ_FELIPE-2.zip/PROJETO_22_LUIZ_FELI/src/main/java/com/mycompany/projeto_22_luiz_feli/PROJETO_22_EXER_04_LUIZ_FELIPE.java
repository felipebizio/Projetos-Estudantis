/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto_22_luiz_feli;
/**
 *
 * @author lbizio
 */
public class PROJETO_22_EXER_04_LUIZ_FELIPE {
    public static void main(String[] args) {
        int [] vetor = new int[10];
        int x=0;

        for (int j = 1; j <= 20; j++){
            if (j % 2 == 0){
                vetor[x] = 1*2;
                x++;
            }
        }
        for(int i=0; i<x;i++){
            System.out.println(vetor[i]+ " ");
        }
    }
    
}
