/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto_22_luiz_feli;

import java.util.Scanner;

/**
 *
 * @author lbizio
 */
public class PROJETO_22_EXER_03_LUIZ_FELIPE {
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        int n = 100;
        int v[] = new int[n];
        int i;
        
        for(i=0;i<=n;i+=2){
            System.out.println(i);
        }
    }
}
