/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto_22_luiz_feli;
import java.util.Scanner;
/**
 *
 * @author lbizio
 */
public class PROJETO_22_EXER_05_LUIZ_FELIPE {
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        double[] vetor = new double[10];
        
        for(int i=0;i<10;i++){
            System.out.println("Informe o " + (i+1) + ":");
            double num = ler.nextDouble();
            vetor[i] = num/2;
        }
        for(int i=0; i<10;i++){
            System.out.println("Números armazenados no vetor divididos por dois");
            System.out.println(vetor[i]+ " ");
        }
    }
    
    
}
