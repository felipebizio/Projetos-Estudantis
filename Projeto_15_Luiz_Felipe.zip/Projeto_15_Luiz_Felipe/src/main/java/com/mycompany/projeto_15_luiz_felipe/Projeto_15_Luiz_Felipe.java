/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_15_luiz_felipe;

/**
 *
 * @author lbizio
 */
public class Projeto_15_Luiz_Felipe {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
