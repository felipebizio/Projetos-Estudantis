/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_luiz_felipe_27;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author lbizio
 */
public class Projeto_Luiz_Felipe_27 extends JFrame {
    private JTextField campoTexto1, campoTexto2, campoTexto3;
    private JButton botao1, botao2, botao3;
    
    public Projeto_Luiz_Felipe_27 () {
        setTitle("Sistema de chamado");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null); // Centraliza a janela na tela
        
        campoTexto1 = new JTextField(10);
        campoTexto2 = new JTextField(10);
        
        botao1 = new JButton ("Entrar");
        botao2 = new JButton("Esqueceu a senha");
        botao3 = new JButton("Cadastre-se");
        
        setLayout(new GridLayout(7, 2)); // GridLayout com 4 linhas e 2 colunas
        
        add(new JLabel(" Login:"));
        add(campoTexto1);
        add(new JLabel(" Senha:"));
        add(campoTexto2);
        add(botao1);
        add(botao2);
        add(botao3);
        
        setVisible(true);
    }
    public static void main(String[] args) {
        // Criando uma instância da classe MinhaTela
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Projeto_Luiz_Felipe_27();
            }
        });
    }
}
