/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_repeticao;

import java.util.Scanner;

/**
 *
 * @author lbizio
 */
public class Projeto_11_Repeticao_While_Luiz_Felipe {

    public static void main(String[] args) {
        
        Scanner ler = new Scanner (System.in);
        
        System.out.println("Digite um número:");
         int  product = ler.nextInt();
         
        while(product<=10)
        {
            
            product=3*product;
            
            System.out.println(product);    
        }
        
    }
}
