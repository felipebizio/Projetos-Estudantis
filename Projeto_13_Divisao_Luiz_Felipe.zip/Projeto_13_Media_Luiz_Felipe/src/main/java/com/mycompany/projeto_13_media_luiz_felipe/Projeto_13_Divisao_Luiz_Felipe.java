/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_13_media_luiz_felipe;

import java.util.Scanner;   

public class Projeto_13_Divisao_Luiz_Felipe {

    public static void main(String[] args) {
        Scanner ler = new Scanner (System.in);
        System.out.println("Digite um valor:");
         int n1 = ler.nextInt();
        System.out.println("Digite outro valor:");
         int n2 = ler.nextInt();
         
         if(n2==0){
          System.out.println("Digite outro valor:");
         }else{
             System.out.println(n1/n2);
         }
    }
    
}
